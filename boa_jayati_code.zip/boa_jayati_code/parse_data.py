import pandas as pd 
import xml.etree.ElementTree as ET
import csv 
from pandas import DataFrame 
import numpy as np


#parse_balance and transaction ledger csv
def parse_ledger(csv_balances, csv_transactions):
    balance_csv = []
    df = pd.read_csv(csv_balances)
    balance_csv = df.to_numpy() #convert to numpy array for effecient and modular access

    transaction_csv = []
    df_two = pd.read_csv(csv_transactions)
    transaction_csv = df_two.to_numpy()
    return balance_csv, transaction_csv

balance_csv, transaction_csv=parse_ledger('templates/LedgerBalance.csv','templates/LedgerTransactions.csv')


balance_table= DataFrame()
transaction_one_table= DataFrame()
transaction_many_table= DataFrame()

#parse swift_xml file using element tree 
def parse_swiftxml(swift_xml):
    xmlfile= swift_xml
    tree = ET.parse(xmlfile)
    root= tree.getroot()
    namespace= root.tag.split('}')[0].strip('{')
    return tree,root, namespace
tree,root,namespace = parse_swiftxml('swift_sample_msg.xml')
#proofing check- check if all data is present 
#if some data is missing,  would be false 


            
def data_check(namespace_xml): 
    st_id_check = True 
    swift_bic_check=True
    bic_list=[]
    gp_hdr_check= True 
    str=''
    #proof check statment id
    for id in root.iter(f"{{{namespace_xml}}}Stmt"):
        stmt_id = id.find(f"{{{namespace_xml}}}Id")
        if stmt_id.text == None: #missing statement id 
            st_id_check= False
            str= ("Basic proofing check failed as statement id missing")
        else: 
            statement_id= stmt_id.text

    #proof check - swift bic 
    for swift in root.iter(f"{{{namespace_xml}}}FinInstnId"):
        bic_code = swift.find(f"{{{namespace_xml}}}BICFI")
        if bic_code.text == None: #missing bic 
            swift_bic_check= False
            str= ("Basic proofing check failed as SWIFT BIC is missing")
        else: 
            bic= bic_code.text
            bic_list.append(bic)
   
    #proof check - message id 
    if (len(bic_list)!=2):
        swift_bic_check=False
        str= ("Basic proofing check failed as one of the SWIFT BIC is missing")

    if (bic_list[0]==bic_list[1]):
        swift_bic_check=False
        str= ("Basic proofing check failed as sender and reciever BIC is same")
    
    #proof check - xml gp header 
    for header in root.iter(f"{{{namespace_xml}}}GrpHdr"):
        message_id = header.find(f"{{{namespace_xml}}}MsgId")
        message_date = header.find(f"{{{namespace_xml}}}CreDtTm")
        
        if message_id.text == None or  message_date.text == None: #missing id 
            gp_hdr_check= False
            str= ("Basic proofing check failed as message id and/or message date missing")

        else:
            msg_id= message_id.text
            message_dtime= message_date.text
            
    if (gp_hdr_check==True and swift_bic_check==True and st_id_check==True and st_id_check==True  ):
        str= "Basic proofing check passed, as the SWIFT data contains a statement id, header, and the SWIFT BIC codes for sender and reciever."
    return str, stmt_id.text
proof_check_results, stmt_id= data_check(namespace)
print(proof_check_results,stmt_id)






#parse transaction enteries and batch enteries  - swift xml 

def parse_transactions(namespace_xml):
    amount_arr=[]
    amount_currency_arr=[]
    type=[]
    date_rr=[]
    batch_amount={}
    for entry in root.iter(f"{{{namespace_xml}}}Ntry"):
        amount = entry.find(f"{{{namespace_xml}}}Amt")
        amount_arr.append(amount.text)
        amount_currency= amount.attrib['Ccy']
        amount_currency_arr.append(amount_currency)
        crd_or_db= entry.find(f"{{{namespace_xml}}}CdtDbtInd")
        type.append(crd_or_db.text)
        for char in entry.findall(f"{{{namespace_xml}}}ValDt"):
            date= char.find(f"{{{namespace_xml}}}Dt")
            date_rr.append(date.text)
        for details in entry.findall(f"{{{namespace_xml}}}NtryDtls"):
            for batch in details.findall(f"{{{namespace_xml}}}Btch"):
                total_amount= batch.find(f"{{{namespace_xml}}}TtlAmt")
                msgid= batch.find(f"{{{namespace_xml}}}MsgId")
                pmtid= batch.find(f"{{{namespace_xml}}}PmtInfId")
                times= batch.find(f"{{{namespace_xml}}}NbOfTxs")
                batch_amount[float(amount.text)]=[float(total_amount.text), pmtid.text, int(times.text),msgid.text]
    return amount_arr,amount_currency_arr,type,date_rr,batch_amount
    
amount_arr,amount_currency_arr,type,date_rr,batch_amount= parse_transactions(namespace)

bal_amount=[]
bal_curr=[]
bal_type=[]
bal_date=[]
bal_code=[]

#parse opening and closing balance - swift xml
def parse_balance(namespace_xml):
    bal_amount=[]
    bal_curr=[]
    bal_type=[]
    bal_date=[]
    bal_code=[]

    for entry in root.iter(f'{{{namespace_xml}}}Bal'):
            amount = entry.find(f'{{{namespace_xml}}}Amt')
            bal_amount.append(amount.text)
            amount_currency= amount.attrib['Ccy']
            bal_curr.append(amount_currency)
            crd_or_db= entry.find(f'{{{namespace_xml}}}CdtDbtInd')
            bal_type.append(crd_or_db.text)
            for code in entry.findall(f'{{{namespace_xml}}}Tp'):
                for trip in code.findall(f'{{{namespace_xml}}}CdOrPrtry'):
                    type_bal= trip.find(f'{{{namespace_xml}}}Cd')
                    bal_code.append(type_bal.text)
            
            for char in entry.findall(f'{{{namespace_xml}}}Dt'):
                date= char.find(f'{{{namespace_xml}}}Dt')
                bal_date.append(date.text)
    transactions={}
    balances={}
    for i in range(len(amount_arr)):
        transactions[i]=[float(amount_arr[i]),amount_currency_arr[i],type[i],date_rr[i]]
    for i in range(len(bal_amount)):
        balances[i]=[float(bal_amount[i]),bal_curr[i],bal_type[i],bal_date[i],bal_code[i]]
    return bal_amount, bal_curr, bal_type, bal_date, bal_code, transactions, balances 
bal_amount, bal_curr, bal_type, bal_date, bal_code, transactions, balances =   parse_balance(namespace)    
                


#balance reconciliation - full integrity check 
#check if account is same - proofing check 
def balance_integrity(namespace_xml,t_csv,b_csv,balance_list,b_table):
    same_string=''
    for account in root.iter(f'{{{namespace_xml}}}Othr'):
        account_id = account.find(f'{{{namespace_xml}}}Id').text
        if((account_id)==b_csv[0][0]):
            bacc_check= ("Balance Reconc: Account ID check passed") #check if account is same 
        if((account_id)==t_csv[0][0]): 
            tacc_check= ("Transac Reconc: Account ID check passed") #check if account is same 

    #balance reconciliation - full integrity check - check opening and closing balance 
    for i in range(len(balance_list)): #balance reconciliation - full integrity check - check opening and closing balance 
        if balance_list[i][0]==b_csv[i][2]:  # full proof- check if account is same 
            same_string += ("{} Balance is the same.".format(balance_list[i][4]))
        else: 
            d=[j for j in range(i)]
            df2=DataFrame({'Account':[b_csv[i][0], account_id],'Currency':[b_csv[i][1],balance_list[i][1]], 'Balance': [b_csv[i][2], balance_list[i][0]], 'AsOfDateTS': [b_csv[i][3],balance_list[i][3]],'Type':[balance_list[i][4],balance_list[i][4]],'Source':['Ledger','SWIFT'],'Difference': [None,-(b_csv[i][2]-balance_list[i][0])]})
            b_table=b_table.append(df2,ignore_index=False)
    return same_string,account_id,bacc_check,tacc_check,b_table

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
same_string,account_id,bacc_check,tacc_check,b_table= balance_integrity(namespace,transaction_csv,balance_csv,balances,balance_table)
print(same_string)
print(b_table)
diff= b_table['Difference'].sum()
type= b_table.loc[1,'Type']
balance_break_diff=""
balance_break_diff+= f"\n Difference between the {type} balance in SWIFT and Ledger (as in SWIFT-LEDGER) is {diff}  "
print(balance_break_diff)

#global variables 
ledger_transaction_list=[element[4] for element in transaction_csv]
ledger_transaction_currency=[element[2] for element in transaction_csv]
ledger_transaction_type=[element[3] for element in transaction_csv]
#transaction reconciliation - full integrity check - one-one check 
#1:1 checking 
def one_to_one(transactions,transaction_one_table,transaction_csv):
    str_one=''
    for i in range(len(transactions)):
        #check if the currency, balance and whether debit or creidt has no discrapancy 
        if transactions[i][0] in ledger_transaction_list and transactions[i][1]==ledger_transaction_currency[i] and transactions[i][2][0]==ledger_transaction_type[i][0]: 
            continue; 
        else: 
            transaction_one_df=DataFrame({'Account':[transaction_csv[i][0], account_id],'Currency':[transaction_csv[i][2],transactions[i][1]], 'Balance': [transaction_csv[i][4], transactions[i][0]], 'AsOfDateTS': [transaction_csv[i][1],transactions[i][3]],'Type':[transaction_csv[i][1],transactions[i][3]],'Source':['Ledger','SWIFT'],'Difference':[None,-(transaction_csv[i][4]-transactions[i][0])]})
            transaction_one_table= transaction_one_table.append(transaction_one_df,ignore_index=True)
    if(transaction_one_table.empty):
        str_one = ("Every entry passed the 1:1 matching, hence no breaks in 1:1 matching")
    return transaction_one_table, str_one
transaction_one_table, str_one= one_to_one(transactions,transaction_one_table,transaction_csv)
if str_one=='':
    str_one= "There are breaks in transaction data as evident in 1:1 Matching shown below"
    
#1:many check - total balance per batch transaction in ledger 
def one_many_check(batch_amount,transaction_many_table):
    
    one_to_many={}
    for item in ledger_transaction_list: 
        one_to_many[item]=[0.0,0]
        for i in range(len(ledger_transaction_list)):
                if ledger_transaction_list[i]==item:
                    one_to_many[item][0]+=item
                    one_to_many[item][1]+=1
    for key,tot in one_to_many.items():
            if key in batch_amount.keys():
                if tot[0]!=batch_amount[key][0]:
                    transaction_many_df=DataFrame({'Account':[account_id, account_id], 'Balance': [key, key], 'TotalAmount': [tot[0],batch_amount[key][0]],'Enteries':[tot[1],batch_amount[key][2]],'Type':['Ledger','SWIFT'],'MessageID':[None,batch_amount[key][1]],'PaymentID':[None, batch_amount[key][1]],'Difference':[None, -(tot[0]-batch_amount[key][0])]})
                    transaction_many_table= transaction_many_table.append(transaction_many_df,ignore_index=False)
    return transaction_many_table
transaction_many_table= one_many_check(batch_amount,transaction_many_table)
diff_many = transaction_many_table['Difference'].sum()
if diff_many!=0:
    str_many=f"Total difference between SWIFT and Ledger Transcations (as in SWIFT-LEDGER) is {diff_many}"
else:
    str_many= f"There is no break in many to many and one to many transactions"
print(str_many)
    

print('Transaction Table Breaks: \n',transaction_many_table)




#create a html 
balance_break_html = b_table.to_html()
transaction_one_html= transaction_one_table.to_html()
transaction_many_html= transaction_many_table.to_html()

# Opening the existing HTML file
Func = open("templates/index.html","w")
text= f'''
<html>\n
<head>\n
<title>\nBOA CODE TO CONNECT\n</title>
\n</head> 
<body style="background-color:#FFDEDE;"> 
<h1>Results of 
<font color = #0065B3>Balance and Transaction Reconciliation </font></h1>\n 
<h2>Account Details</h2>\n 
<p>The following are reconciliation results of Account Number: <strong>{account_id}</strong> for Statement ID: <strong>{stmt_id}</strong>  </p>
<h2>Basic Proofing</h2>\n 
<span style="color:green; border:2px solid" > {proof_check_results} </span>
<h2>Balance Reconciliation</h2>\n 
<p> {bacc_check} <br>
{same_string} <br>
However there is a <font color = #E61030> break</font> in the data shown below: <br> <br>
 {balance_break_html} <br> 
<span style="color:red ; border:2px solid" > {balance_break_diff} </span> </p>
<h2>Transaction Reconciliation</h2>\n 
<p>{str_one}</p>

<p>{transaction_one_html}</p>
<p> Thus, there are <font color = #E61030> breaks</font> in 1:N and M:N matching shown in the table below.<br> 
The Enteries column corresponds to total enteries in the batch of that particular transaction entry in ledger and SWIFT data. </p>
<p> {transaction_many_html} </p>
<span style="color:red ; border:2px solid" > {str_many} </span>
<h2>Analysis of Results</h2>\n 
<p style="text-align: justify;"> From the results it can be interpreted that there is a break in the swift and ledger data as seen through the matching algorithm. 
This break is consistent. The Ledger Closing Balance is $3,000,000 lower than SWIFT Closing Balance. 
 As such, this is consistent as seen in the 1:N and M:N matching algorithm since the total difference between the breaks in SWIFT and Ledger is $-3,000,000. 
 This implies that there are extra transactions in batch transations for the ledger as compared to SWIFT and this is evident in the inconsistency/break in the Enteries column in the table above, <br> 
which explains why the ledger closing balance is $3000000 lower than SWIFT. </p>


</body></html>

'''
# Adding input data to the HTML file
Func.write(text)
  
# Saving the data into the HTML file
Func.close()